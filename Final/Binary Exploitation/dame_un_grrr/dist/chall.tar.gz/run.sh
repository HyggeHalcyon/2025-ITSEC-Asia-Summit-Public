#!/bin/bash

exec timeout -sKILL 120 qemu-system-aarch64 \
    -machine virt \
    -m 128M \
    -cpu cortex-a55 \
    -smp cores=1,threads=1 \
    -kernel ./Image \
    -initrd ./initramfs.cpio.gz \
    -no-reboot \
    -append "console=ttyAMA0 kaslr smep smap kpti=on quiet log_level=3 panic=1 oops=panic" \
    -nographic 