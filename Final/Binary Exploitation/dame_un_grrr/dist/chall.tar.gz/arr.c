#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>


#define DEVICE_NAME "arr_device"
#define IOCTL_MAGIC 'k'
#define IOCTL_SET_VALUE      _IOW(IOCTL_MAGIC, 1, int)
#define IOCTL_GET_VALUE      _IOR(IOCTL_MAGIC, 2, int)
#define IOCTL_SET_STRING     _IOW(IOCTL_MAGIC, 3, char*)
#define IOCTL_GET_STRING     _IOR(IOCTL_MAGIC, 4, char*)
#define IOCTL_SET_STRUCT     _IOW(IOCTL_MAGIC, 5, struct my_data)
#define IOCTL_GET_STRUCT     _IOR(IOCTL_MAGIC, 6, struct my_data)
#define IOCTL_SET_BUFFER     _IOW(IOCTL_MAGIC, 7, struct buffer_data)
#define IOCTL_GET_BUFFER     _IOR(IOCTL_MAGIC, 8, struct buffer_data)
#define IOCTL_SET_PARTIAL    _IOW(IOCTL_MAGIC, 9, struct partial_data)
#define IOCTL_COPY_EXACT     _IOW(IOCTL_MAGIC, 10, struct exact_copy_data)

#define MAX_STRING_LEN 256
#define MAX_BUFFER_SIZE 1024

struct my_data {
    int value;
    char name[64];
    long timestamp;
};

struct buffer_data {
    char __user *buffer;    
    size_t length;          
    size_t max_length;      
};

struct partial_data {
    char __user *source;    
    size_t total_size;      
    int16_t offset_from;    
    int16_t offset_to;
    size_t copy_length;     
};

struct exact_copy_data {
    char __user *data;      
    size_t length;          
    char padding[32];       
};

static int stored_value = 0;
static struct my_data stored_data = {0, "initial", 0};
static size_t stored_buffer_length = 0;


static dev_t dev_id;
static struct cdev c_dev;

static long module_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{

    char local_buffer[MAX_BUFFER_SIZE];
    int local_int;
    struct my_data local_data;
    struct buffer_data local_buf_info;
    struct partial_data local_partial;
    size_t copy_len;
    int ret = 0;

    printk(KERN_INFO "mydevice: ioctl called with cmd = 0x%x\n", cmd);

    if (_IOC_TYPE(cmd) != IOCTL_MAGIC) {
        printk(KERN_ERR "mydevice: Invalid ioctl magic number\n");
        return -ENOTTY;
    }

    switch (cmd) {
        case IOCTL_SET_VALUE:
            printk(KERN_INFO "mydevice: IOCTL_SET_VALUE\n");
            
            if (copy_from_user(&local_int, (int __user *)arg, sizeof(int))) {
                printk(KERN_ERR "mydevice: Failed to copy %zu bytes from user space\n", sizeof(int));
                return -EFAULT;
            }
            
            if (local_int < 0) {
                printk(KERN_WARNING "mydevice: Negative value received: %d\n", local_int);
                return -EINVAL;
            }
            
            stored_value = local_int;
            printk(KERN_INFO "mydevice: Copied %zu bytes, value set to %d\n", sizeof(int), stored_value);
            break;

        case IOCTL_GET_VALUE:
            printk(KERN_INFO "mydevice: IOCTL_GET_VALUE\n");
            
            local_int = stored_value;
            
            if (copy_to_user((int __user *)arg, &local_int, sizeof(int))) {
                printk(KERN_ERR "mydevice: Failed to copy %zu bytes to user space\n", sizeof(int));
                return -EFAULT;
            }
            
            printk(KERN_INFO "mydevice: Copied %zu bytes, returned value %d to user\n", sizeof(int), local_int);
            break;
        case IOCTL_SET_BUFFER:
            printk(KERN_INFO "mydevice: IOCTL_SET_BUFFER with specific length\n");
            
            if (copy_from_user(&local_buf_info, (struct buffer_data __user *)arg, sizeof(struct buffer_data))) {
                printk(KERN_ERR "mydevice: Failed to copy buffer info structure\n");
                return -EFAULT;
            }
            
            if (local_buf_info.length > local_buf_info.max_length) {
                printk(KERN_ERR "mydevice: Copy length (%zu) exceeds max length (%zu)\n", 
                       local_buf_info.length, local_buf_info.max_length);
                return -EINVAL;
            }

            memset(local_buffer, 0, sizeof(local_buffer));
            
            copy_len = local_buf_info.length;
            if (raw_copy_from_user(local_buffer, local_buf_info.buffer, copy_len)) {
                printk(KERN_ERR "mydevice: Failed to copy %zu bytes from user buffer\n", copy_len);
                return -EFAULT;
            }
            
            stored_buffer_length = copy_len;
            
            printk(KERN_INFO "mydevice: Successfully copied %zu bytes to kernel buffer\n", copy_len);
            break;

        case IOCTL_GET_BUFFER:
            printk(KERN_INFO "mydevice: IOCTL_GET_BUFFER with specific length\n");
            
            if (copy_from_user(&local_buf_info, (struct buffer_data __user *)arg, sizeof(struct buffer_data))) {
                printk(KERN_ERR "mydevice: Failed to copy buffer info structure\n");
                return -EFAULT;
            }

            if (local_buf_info.length > local_buf_info.max_length) {
                printk(KERN_ERR "mydevice: Copy length (%zu) exceeds max length (%zu)\n", 
                       local_buf_info.length, local_buf_info.max_length);
                return -EINVAL;
            }


            copy_len = local_buf_info.length;
            
            if (copy_len == 0) {
                printk(KERN_WARNING "mydevice: No data to copy\n");
                return -ENODATA;
            }
            
            
            if (raw_copy_to_user(local_buf_info.buffer, local_buffer, copy_len)) {
                printk(KERN_ERR "mydevice: Failed to copy %zu bytes to user buffer\n", copy_len);
                return -EFAULT;
            }
            

            
            printk(KERN_INFO "mydevice: Successfully copied %zu bytes to user buffer\n", copy_len);
            break;
        case IOCTL_SET_PARTIAL:
            printk(KERN_INFO "mydevice: IOCTL_SET_PARTIAL - copying with offset and specific length\n");
            
            if (copy_from_user(&local_partial, (struct partial_data __user *)arg, sizeof(struct partial_data))) {
                printk(KERN_ERR "mydevice: Failed to copy partial data structure\n");
                return -EFAULT;
            }

            copy_len = local_partial.copy_length;

            if (copy_len == 0) {
                printk(KERN_WARNING "mydevice: No bytes to copy\n");
                return -EINVAL;
            }
            
            memset(local_buffer, 0, sizeof(local_buffer));
            
            if (raw_copy_from_user(local_buffer + local_partial.offset_to, local_partial.source + local_partial.offset_from, copy_len)) {
                printk(KERN_ERR "mydevice: Failed to copy %zu bytes\n", 
                       copy_len);
                return -EFAULT;
            }
            

            
            break;
        case IOCTL_SET_STRUCT:
            printk(KERN_INFO "mydevice: IOCTL_SET_STRUCT\n");
            
            copy_len = sizeof(struct my_data);
            if (copy_from_user(&local_data, (struct my_data __user *)arg, copy_len)) {
                printk(KERN_ERR "mydevice: Failed to copy %zu bytes of struct from user space\n", copy_len);
                return -EFAULT;
            }
            
            if (local_data.value < 0) {
                printk(KERN_WARNING "mydevice: Invalid value in struct: %d\n", local_data.value);
                return -EINVAL;
            }
            
            local_data.name[sizeof(local_data.name) - 1] = '\0';
            
            stored_data = local_data;
            printk(KERN_INFO "mydevice: Copied %zu bytes, struct set - value: %d, name: '%s', timestamp: %ld\n",
                   copy_len, stored_data.value, stored_data.name, stored_data.timestamp);
            break;

        case IOCTL_GET_STRUCT:
            printk(KERN_INFO "mydevice: IOCTL_GET_STRUCT\n");
            
            local_data = stored_data;
            local_data.timestamp = jiffies; 
            
            copy_len = sizeof(struct my_data);
            if (copy_to_user((struct my_data __user *)arg, &local_data, copy_len)) {
                printk(KERN_ERR "mydevice: Failed to copy %zu bytes of struct to user space\n", copy_len);
                return -EFAULT;
            }
            
            printk(KERN_INFO "mydevice: Copied %zu bytes, returned struct - value: %d, name: '%s', timestamp: %ld\n",
                   copy_len, local_data.value, local_data.name, local_data.timestamp);
            break;
        default:
            printk(KERN_ERR "mydevice: Invalid ioctl command: 0x%x\n", cmd);
            return -ENOTTY;
    }

    return ret;
}

static int module_open(struct inode *inode, struct file *file) {
    return 0;
}
static int module_release(struct inode *inode, struct file *file) {
    return 0;
}

static const struct file_operations module_fops = {
    .owner = THIS_MODULE,
    .open = module_open,
    .release = module_release,
    .unlocked_ioctl = module_ioctl,
};

static int __init module_initialize(void)
{
    if (alloc_chrdev_region(&dev_id, 0, 1, DEVICE_NAME))
        return -EBUSY;

    cdev_init(&c_dev, &module_fops);
    c_dev.owner = THIS_MODULE;

    if (cdev_add(&c_dev, dev_id, 1)) {
        unregister_chrdev_region(dev_id, 1);
        return -EBUSY;
    }

    printk(KERN_INFO "arr device registered\n");
    return 0;
}

static void __exit module_cleanup(void)
{
    cdev_del(&c_dev);
    unregister_chrdev_region(dev_id, 1);
    printk(KERN_INFO "arr device unregistered\n");
}

module_init(module_initialize);
module_exit(module_cleanup);

MODULE_LICENSE("GPL");
