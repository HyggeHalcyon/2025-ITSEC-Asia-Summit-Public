#!/bin/bash

sudo docker compose up --build --force-recreate -d