#!/bin/sh

service xinetd start && exec sleep infinity
