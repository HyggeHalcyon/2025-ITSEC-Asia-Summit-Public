#define _WIN32_WINNT 0x0601     
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include <time.h>       
#include <windows.h>

#define BUFFER_SIZE 4096

#pragma comment(lib, "ws2_32.lib")

static void handle_client(SOCKET client);   

static void wsa_perror(const char *msg)
{
    fprintf(stderr, "[!] %s: %d\n", msg, WSAGetLastError());
}

int __cdecl main(int argc, char **argv)
{
    (void)argc; (void)argv;          /* unused */

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        wsa_perror("WSAStartup failed");
        return 1;
    }

    struct addrinfo hints  = { 0 }, *result = NULL;
    hints.ai_family        = AF_INET;       /* IPv4 */
    hints.ai_socktype      = SOCK_STREAM;   /* TCP  */
    hints.ai_protocol      = IPPROTO_TCP;
    hints.ai_flags         = AI_PASSIVE;    /* for bind() */

    if (getaddrinfo(NULL, "8433", &hints, &result) != 0) {
        wsa_perror("getaddrinfo failed");
        WSACleanup();
        return 1;
    }

    SOCKET listen_sock = socket(result->ai_family,
                                result->ai_socktype,
                                result->ai_protocol);
    if (listen_sock == INVALID_SOCKET) {
        wsa_perror("socket() error");
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    if (bind(listen_sock, result->ai_addr, (int)result->ai_addrlen) == SOCKET_ERROR) {
        wsa_perror("bind() failed");
        freeaddrinfo(result);
        closesocket(listen_sock);
        WSACleanup();
        return 1;
    }

    freeaddrinfo(result); 

    if (listen(listen_sock, SOMAXCONN) == SOCKET_ERROR) {
        wsa_perror("listen() failed");
        closesocket(listen_sock);
        WSACleanup();
        return 1;
    }

    puts("[+] Server is up and running ...");

    for (;;) {
        struct sockaddr_in  cli_addr;
        int                 cli_len = sizeof(cli_addr);

        puts("[+] Waiting for incoming connections 8433...");
        SOCKET client_sock = accept(listen_sock,
                                    (struct sockaddr *)&cli_addr,
                                    &cli_len);
        if (client_sock == INVALID_SOCKET) {
            wsa_perror("accept() failed");
            break;                     
        }

        char ipstr[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &cli_addr.sin_addr, ipstr, sizeof ipstr);
        printf("[+] Received a client connection from %s:%u\n",
               ipstr, ntohs(cli_addr.sin_port));

        handle_client(client_sock);
    }

    closesocket(listen_sock);
    WSACleanup();
    return 0;
}

void handle_time(SOCKET client)
{
    char buf[128];
    time_t now = time(NULL);
    snprintf(buf, sizeof(buf), "[TIME] %s", ctime(&now));
    send(client, buf, (int)strlen(buf), 0);
}

void handle_info(SOCKET client)
{
    char buf[512];
    DWORD pid = GetCurrentProcessId();
    char exePath[MAX_PATH] = {0};

    GetModuleFileNameA(NULL, exePath, MAX_PATH);

    snprintf(buf, sizeof(buf),
             "[INFO] PID: %lu | Executable: %s\n",
             (unsigned long)pid,
             exePath);

    send(client, buf, (int)strlen(buf), 0);
}

int check_file(const char *filename)
{
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        return 0;  // false = does not exist
    }
    fclose(fp);
    return 1;  // true = exists
}

void handle_open(SOCKET client, const char *buff)
{
    char filename[256];

    sscanf(buff + 5, "%s", filename);

    // Check if the file exists
    if (!check_file(filename)) {
        const char *msg_fail = "[ERR] Cannot open the file\n";
        send(client, msg_fail, (int)strlen(msg_fail), 0); 
        return;
    }

    // If the file exists, inform the client
    const char *msg_success = "[ERR] Cannot open the file\n";
    send(client, msg_success, (int)strlen(msg_success), 0);
}

void handle_exit(SOCKET client)
{
    const char *msg = "[*] Goodbye.\n";
    send(client, msg, (int)strlen(msg), 0);
}

void handle_unknown(SOCKET client)
{
    const char *msg = "[ERR] Unknown command.\n";
    send(client, msg, (int)strlen(msg), 0);
}


static void handle_client(SOCKET client)
{
    char  buf[BUFFER_SIZE];
    int   n_recv;

    for (;;) {
        n_recv = recv(client, buf, sizeof(buf) - 1, 0);

        if (n_recv == 0) {
            puts("[*] Client disconnected");
            break;
        }
        if (n_recv == SOCKET_ERROR) {
            wsa_perror("recv() failed");
            break;
        }

        buf[n_recv] = '\0';
        printf("[>] Received\n");

        // Command dispatch
        if (_strnicmp(buf, "TIME", 4) == 0) {
            handle_time(client);
        }
        else if (_strnicmp(buf, "INFO", 4) == 0) {
            handle_info(client);
        }
        else if (_strnicmp(buf, "OPEN ", 5) == 0) {
            
            handle_open(client, buf);
        }
        else if (_strnicmp(buf, "EXIT", 4) == 0) {
            handle_exit(client);
            break;
        }
        else {
            handle_unknown(client);
        }
    }

    shutdown(client, SD_BOTH);
    closesocket(client);
}