#!/bin/bash
PlanUUID="$1"

docker run --init --network=host --name not_so_planned_bot-$(</proc/sys/kernel/random/uuid) -d --rm -e TIMEOUT=60 -e SERVER=http://localhost:3000 -e UUID=$PlanUUID not_so_planned_bot